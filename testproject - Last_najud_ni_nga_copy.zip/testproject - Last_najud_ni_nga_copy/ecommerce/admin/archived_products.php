<?php
$page_title = "Archived Products";

require_once __DIR__ . '/../includes/db_connect.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/inc_admin_auth.php';
include __DIR__ . '/../includes/header.php';

// ✅ Fetch all archived products
$sql = "SELECT * FROM products WHERE is_archived = 1 ORDER BY product_id DESC";
$result = $mysqli->query($sql);
?>

<div class="container py-4">
  <h2 class="mb-4 text-center">🗃 Archived Products</h2>

  <?php if (isset($_SESSION['flash'])): ?>
    <div class="alert alert-<?= $_SESSION['flash']['type'] ?>">
      <?= htmlspecialchars($_SESSION['flash']['msg']) ?>
    </div>
    <?php unset($_SESSION['flash']); ?>
  <?php endif; ?>

  <?php if ($result && $result->num_rows > 0): ?>
    <div class="table-responsive">
      <table class="table table-bordered table-hover bg-white">
        <thead class="table-dark text-center">
          <tr>
            <th>ID</th>
            <th>Product</th>
            <th>Price</th>
            <th>Stock</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          <?php while ($row = $result->fetch_assoc()): ?>
            <tr>
              <td class="text-center"><?= $row['product_id'] ?></td>
              <td><?= htmlspecialchars($row['name']) ?></td>
              <td class="text-end">₱<?= number_format($row['price'], 2) ?></td>
              <td class="text-center"><?= $row['stock'] ?></td>
              <td class="text-center">
                <form method="POST" action="restore_product.php" style="display:inline;">
                  <input type="hidden" name="product_id" value="<?= $row['product_id'] ?>">
                  <button type="submit" class="btn btn-sm btn-success">Restore</button>
                </form>
              </td>
            </tr>
          <?php endwhile; ?>
        </tbody>
      </table>
    </div>
  <?php else: ?>
    <p class="text-center text-muted">No archived products found.</p>
  <?php endif; ?>
</div>

<?php include '../includes/footer.php'; ?>
