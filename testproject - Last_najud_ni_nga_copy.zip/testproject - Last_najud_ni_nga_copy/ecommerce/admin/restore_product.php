<?php
require_once __DIR__ . '/../includes/db_connect.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/inc_admin_auth.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: archived_products.php');
    exit;
}

$product_id = (int)($_POST['product_id'] ?? 0);

if ($product_id <= 0) {
    $_SESSION['flash'] = ['type' => 'danger', 'msg' => 'Invalid product ID.'];
    header('Location: archived_products.php');
    exit;
}

$stmt = $mysqli->prepare("UPDATE products SET is_archived = 0 WHERE product_id = ?");
$stmt->bind_param('i', $product_id);

if ($stmt->execute()) {
    $_SESSION['flash'] = ['type' => 'success', 'msg' => 'Product restored successfully!'];
    
    // Optional: log admin action
   /* if (isset($_SESSION['user_id'])) {
        $admin_id = $_SESSION['user_id'];
        $action = "Restored product ID: {$product_id}";
        $log = $mysqli->prepare("INSERT INTO admin_logs (admin_id, action) VALUES (?, ?)");
        $log->bind_param("is", $admin_id, $action);
        $log->execute();
        $log->close();
    }*/
} else {
    $_SESSION['flash'] = ['type' => 'danger', 'msg' => 'Restore failed: ' . $stmt->error];
}
$stmt->close();

header('Location: archived_products.php');
exit;
?>
