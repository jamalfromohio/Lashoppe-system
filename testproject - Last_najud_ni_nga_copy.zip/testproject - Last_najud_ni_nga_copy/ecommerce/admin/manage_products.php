<?php
// admin/manage_products.php
$page_title = "Admin Dashboard";

// Step 1: Include core dependencies
require_once __DIR__ . '/../includes/db_connect.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/config.php';

// Step 2: Enforce admin-only access
require_once __DIR__ . '/inc_admin_auth.php';

// Start session if not already
if (session_status() === PHP_SESSION_NONE) session_start();

// Simple flash messages using session
$flash = $_SESSION['flash'] ?? null;
unset($_SESSION['flash']);

// CSRF token for forms
if (empty($_SESSION['csrf_token'])) $_SESSION['csrf_token'] = bin2hex(random_bytes(24));
$csrf = $_SESSION['csrf_token'];

// Pagination setup
$perPage = 20;
$page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
$offset = ($page - 1) * $perPage;

// total count for pagination (only active)
$countRes = $mysqli->query("SELECT COUNT(*) AS cnt FROM products WHERE is_archived = 0");
$total = ($countRes) ? (int)$countRes->fetch_assoc()['cnt'] : 0;
$totalPages = max(1, ceil($total / $perPage));

// main query with category name
$stmt = $mysqli->prepare("
  SELECT p.product_id, p.name, p.price, p.stock, p.image, c.name AS category_name
  FROM products p
  LEFT JOIN categories c ON p.category_id = c.category_id
  WHERE p.is_archived = 0
  ORDER BY p.product_id DESC
  LIMIT ? OFFSET ?
");
$stmt->bind_param("ii", $perPage, $offset);
$stmt->execute();
$res = $stmt->get_result();

include __DIR__ . '/../includes/header.php';
?>
<div class="container py-4">
  <div class="d-flex justify-content-between align-items-center mb-3">
    <h3>Manage Products</h3>
    <div>
      <a class="btn btn-secondary me-2" href="archived_products.php">View Archived</a>
      <a class="btn btn-success" href="add_product.php">Add Product</a>
    </div>
  </div>

  <?php if ($flash): ?>
    <div class="alert alert-<?= htmlspecialchars($flash['type']) ?>"><?= htmlspecialchars($flash['msg']) ?></div>
  <?php endif; ?>

  <table class="table table-striped">
    <thead>
      <tr>
        <th>ID</th>
        <th>Image</th>
        <th>Name</th>
        <th>Price</th>
        <th>Stock</th>
        <th>Category</th>
        <th>Actions</th>
      </tr>
    </thead>
    <tbody>
      <?php while ($row = $res->fetch_assoc()): ?>
        <tr>
          <td><?= (int)$row['product_id'] ?></td>
          <td>
            <?php if (!empty($row['image']) && file_exists(__DIR__ . '/../uploads/' . $row['image'])): ?>
              <img src="<?= BASE_URL ?>/uploads/<?= htmlspecialchars($row['image']) ?>" 
                   alt="<?= htmlspecialchars($row['name']) ?>" 
                   style="height:60px;object-fit:cover">
            <?php else: ?>
              <img src="https://dummyimage.com/80x60/dee2e6/6c757d.jpg" alt="" style="height:60px">
            <?php endif; ?>
          </td>
          <td><?= htmlspecialchars($row['name']) ?></td>
          <td>₱<?= number_format($row['price'], 2) ?></td>
          <td><?= (int)$row['stock'] ?></td>
          <td><?= htmlspecialchars($row['category_name'] ?? '') ?></td>
          <td>
            <a class="btn btn-sm btn-primary" href="edit_product.php?id=<?= (int)$row['product_id'] ?>">Edit</a>

            <!-- Archive form (POST + CSRF) -->
            <form method="post" action="delete_product.php" style="display:inline" onsubmit="return confirm('Archive this product?');">
              <input type="hidden" name="product_id" value="<?= (int)$row['product_id'] ?>">
              <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf) ?>">
              <button class="btn btn-sm btn-warning" type="submit">Archive</button>
            </form>
          </td>
        </tr>
      <?php endwhile; ?>
      <?php if ($total === 0): ?>
        <tr><td colspan="7" class="text-center">No active products found.</td></tr>
      <?php endif; ?>
    </tbody>
  </table>

  <!-- Pagination -->
  <?php if ($totalPages > 1): ?>
    <nav>
      <ul class="pagination">
        <?php for ($p = 1; $p <= $totalPages; $p++): ?>
          <li class="page-item <?= $p === $page ? 'active' : '' ?>">
            <a class="page-link" href="manage_products.php?page=<?= $p ?>"><?= $p ?></a>
          </li>
        <?php endfor; ?>
      </ul>
    </nav>
  <?php endif; ?>
</div>

<?php
$stmt->close();
include __DIR__ . '/../includes/footer.php';
?>
