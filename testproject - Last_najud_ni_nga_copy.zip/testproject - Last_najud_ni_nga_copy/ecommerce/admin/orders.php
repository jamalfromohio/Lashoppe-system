<?php
$page_title = "Manage Orders";

require_once __DIR__ . '/../includes/db_connect.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/inc_admin_auth.php'; // restrict to admins only
include __DIR__ . '/../includes/header.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Handle status update (with redirect)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['order_id'], $_POST['new_status'])) {
    $order_id = (int)$_POST['order_id'];
    $new_status = trim($_POST['new_status']);

    $stmt = $mysqli->prepare("UPDATE orders SET status = ? WHERE order_id = ?");
    $stmt->bind_param("si", $new_status, $order_id);
    $stmt->execute();
    $stmt->close();

    // ✅ Store success message for next load
    $_SESSION['flash'] = [
        'type' => 'success',
        'msg' => "✅ Order #$order_id status updated to '$new_status'."
    ];

    // ✅ Refresh the page to show updated status immediately
    header("Location: orders.php");
    exit;
}

// Fetch all orders with usernames
$sql = "
    SELECT 
        o.order_id,
        o.user_id,
        o.order_date,
        o.status,
        o.total_amount,
        u.username,
        u.email
    FROM orders o
    JOIN users u ON o.user_id = u.user_id
    ORDER BY o.order_date DESC
";
$result = $mysqli->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title><?= htmlspecialchars($page_title) ?></title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
  <style>
    .fade-out {
      transition: opacity 0.5s ease-out;
      opacity: 1;
    }
  </style>
</head>
<body class="bg-light">

<div class="container py-4">
  <h2 class="mb-4 text-center">📦 Customer Orders</h2>

  <!-- ✅ Flash message -->
  <?php if (!empty($_SESSION['flash'])): ?>
    <div id="flashMessage" class="alert alert-<?= $_SESSION['flash']['type'] ?> text-center">
      <?= htmlspecialchars($_SESSION['flash']['msg']) ?>
    </div>
    <?php unset($_SESSION['flash']); ?>
  <?php endif; ?>

  <?php if ($result && $result->num_rows > 0): ?>
  <div class="table-responsive">
    <table class="table table-bordered table-hover bg-white">
      <thead class="table-dark text-center">
        <tr>
          <th>Order ID</th>
          <th>Customer</th>
          <th>Email</th>
          <th>Date</th>
          <th>Status</th>
          <th>Total (₱)</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php while ($row = $result->fetch_assoc()): ?>
          <tr>
            <td class="text-center"><?= htmlspecialchars($row['order_id']) ?></td>
            <td><?= htmlspecialchars($row['username']) ?></td>
            <td><?= htmlspecialchars($row['email']) ?></td>
            <td><?= htmlspecialchars($row['order_date']) ?></td>
            <td>
              <form method="POST" class="d-flex align-items-center justify-content-center gap-2">
                <input type="hidden" name="order_id" value="<?= $row['order_id'] ?>">
                <select name="new_status" class="form-select form-select-sm w-auto">
                  <?php
                    $statuses = ['Pending', 'Shipped', 'Delivered', 'Cancelled'];
                    foreach ($statuses as $status):
                  ?>
                    <option value="<?= $status ?>" <?= $row['status'] === $status ? 'selected' : '' ?>>
                      <?= $status ?>
                    </option>
                  <?php endforeach; ?>
                </select>
                <button type="submit" class="btn btn-sm btn-outline-primary">Update</button>
              </form>
            </td>
            <td class="text-end"><?= number_format($row['total_amount'], 2) ?></td>
            <td class="text-center">
              <a href="order_details.php?order_id=<?= $row['order_id'] ?>" class="btn btn-sm btn-info text-white">View Details</a>
            </td>
          </tr>
        <?php endwhile; ?>
      </tbody>
    </table>
  </div>
  <?php else: ?>
    <p class="text-center text-muted">No orders found.</p>
  <?php endif; ?>
</div>

<script>
  // ✅ Auto fade-out flash message after 2 seconds
  setTimeout(() => {
    const msg = document.getElementById('flashMessage');
    if (msg) {
      msg.style.opacity = '0';
      setTimeout(() => msg.remove(), 500);
    }
  }, 2000);
</script>

</body>
</html>
<?php include '../includes/footer.php'; ?>
