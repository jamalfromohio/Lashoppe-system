<?php
$page_title = "Admin Dashboard";

// Step 1: Include core dependencies
require_once __DIR__ . '/../includes/db_connect.php';
require_once __DIR__ . '/../includes/functions.php';

// Step 2: Enforce admin-only access
require_once __DIR__ . '/inc_admin_auth.php';

// Step 3: Load global header (auto-loads admin_nav.php if in /admin/)
include __DIR__ . '/../includes/header.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: manage_products.php');
    exit;
}

// ✅ CSRF protection
if (empty($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
    $_SESSION['flash'] = ['type' => 'danger', 'msg' => 'Invalid CSRF token.'];
    header('Location: manage_products.php');
    exit;
}

// ✅ Validate product ID
$id = isset($_POST['product_id']) ? (int)$_POST['product_id'] : 0;
if ($id <= 0) {
    $_SESSION['flash'] = ['type' => 'warning', 'msg' => 'Invalid product ID.'];
    header('Location: manage_products.php');
    exit;
}

// ✅ Check if product exists
$stmt = $mysqli->prepare("SELECT product_id, name, image, is_archived FROM products WHERE product_id = ? LIMIT 1");
$stmt->bind_param('i', $id);
$stmt->execute();
$res = $stmt->get_result();
$product = $res->fetch_assoc();
$stmt->close();

if (!$product) {
    $_SESSION['flash'] = ['type' => 'danger', 'msg' => 'Product not found.'];
    header('Location: manage_products.php');
    exit;
}

// ✅ ARCHIVE the product instead of deleting
$update = $mysqli->prepare("UPDATE products SET is_archived = 1 WHERE product_id = ?");
$update->bind_param('i', $id);

if ($update->execute()) {
    $_SESSION['flash'] = ['type' => 'success', 'msg' => 'Product archived successfully.'];
    
    // Optional: Log admin action (if you have an admin_logs table)
   /* if (isset($_SESSION['user_id'])) {
        $admin_id = $_SESSION['user_id'];
        $action = "Archived product ID: {$product['product_id']} ({$product['name']})";
        $log = $mysqli->prepare("INSERT INTO admin_logs (admin_id, action) VALUES (?, ?)");
        $log->bind_param("is", $admin_id, $action);
        $log->execute();
        $log->close();
    }*/
} else {
    $_SESSION['flash'] = ['type' => 'danger', 'msg' => 'Archiving failed: ' . $update->error];
}
$update->close();

header('Location: manage_products.php');
exit;
?>
