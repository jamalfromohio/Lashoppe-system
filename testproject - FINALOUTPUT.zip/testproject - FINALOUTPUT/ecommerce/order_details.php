<?php
session_start();
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/db_connect.php';

// 🔒 Redirect if not logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: ' . BASE_URL . '/auth/login.php');
    exit;
}

$user_id = $_SESSION['user_id'];
$order_id = isset($_GET['order_id']) ? (int)$_GET['order_id'] : 0;

if ($order_id <= 0) {
    die('Invalid order ID.');
}

// 🧾 Fetch order summary
$stmt = $mysqli->prepare("SELECT * FROM orders WHERE order_id = ? AND user_id = ?");
$stmt->bind_param("ii", $order_id, $user_id);
$stmt->execute();
$order = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$order) {
    die('Order not found or you do not have permission to view it.');
}

// 📦 Fetch ordered items
$sql = "
    SELECT 
        oi.order_item_id,
        oi.quantity,
        oi.price,
        p.name AS product_name,
        p.image
    FROM order_items oi
    JOIN products p ON oi.product_id = p.product_id
    WHERE oi.order_id = ?
";
$stmt = $mysqli->prepare($sql);
$stmt->bind_param("i", $order_id);
$stmt->execute();
$items = $stmt->get_result();
$stmt->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Order Details #<?= htmlspecialchars($order_id) ?></title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
</head>
<body class="bg-light">
<div class="container py-4">
  <h2>🧾 Order #<?= htmlspecialchars($order_id) ?></h2>
  <p><strong>Date:</strong> <?= htmlspecialchars($order['order_date']) ?></p>
  <p><strong>Status:</strong> <?= htmlspecialchars($order['status']) ?></p>
  <p><strong>Shipping Address:</strong> <?= htmlspecialchars($order['shipping_address']) ?></p>
  <p><strong>Total Amount:</strong> ₱<?= number_format($order['total_amount'], 2) ?></p>

  <hr>
  <h4>Items in this Order</h4>
  <table class="table table-bordered bg-white">
    <thead>
      <tr>
        <th>Product</th>
        <th>Image</th>
        <th>Quantity</th>
        <th>Unit Price</th>
        <th>Subtotal</th>
      </tr>
    </thead>
    <tbody>
      <?php 
      $grandTotal = 0;
      while ($item = $items->fetch_assoc()): 
          $subtotal = $item['price'] * $item['quantity'];
          $grandTotal += $subtotal;
      ?>
      <tr>
        <td><?= htmlspecialchars($item['product_name']) ?></td>
        <td>
          <?php if (!empty($item['image'])): ?>
            <img src="uploads/<?= htmlspecialchars($item['image']) ?>" alt="Product image" width="60">
          <?php else: ?>
            <span class="text-muted">No image</span>
          <?php endif; ?>
        </td>
        <td><?= (int)$item['quantity'] ?></td>
        <td>₱<?= number_format($item['price'], 2) ?></td>
        <td>₱<?= number_format($subtotal, 2) ?></td>
      </tr>
      <?php endwhile; ?>
    </tbody>
  </table>

  <h5 class="text-end">Grand Total: ₱<?= number_format($grandTotal, 2) ?></h5>
  <a href="profile.php" class="btn btn-secondary mt-3">← Back to My Orders</a>
</div>
</body>
</html>
