<?php
// admin/admin_nav.php
if (session_status() === PHP_SESSION_NONE) session_start();
?>

<!-- Admin Navigation -->
<nav class="navbar navbar-expand-lg navbar-light bg-light border-bottom mb-4">
  <div class="container px-4 px-lg-5">
    <a class="navbar-brand fw-bold" href="dashboard.php">Admin Panel</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
      data-bs-target="#adminNavbar" aria-controls="adminNavbar" aria-expanded="false"
      aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>

    <div class="collapse navbar-collapse" id="adminNavbar">
      <!-- Left: main admin links -->
      <ul class="navbar-nav me-auto mb-2 mb-lg-0 ms-lg-4">
        <li class="nav-item"><a class="nav-link<?= basename($_SERVER['PHP_SELF']) === 'dashboard.php' ? ' active' : '' ?>" href="dashboard.php">Dashboard</a></li>
        <li class="nav-item"><a class="nav-link<?= basename($_SERVER['PHP_SELF']) === 'manage_products.php' ? ' active' : '' ?>" href="manage_products.php">Manage Products</a></li>
        <li class="nav-item"><a class="nav-link<?= basename($_SERVER['PHP_SELF']) === 'add_product.php' ? ' active' : '' ?>" href="add_product.php">Add Product</a></li>
      </ul>

      <!-- Right: shortcuts -->
      <ul class="navbar-nav mb-2 mb-lg-0">
        <li class="nav-item"><a class="nav-link" href="../index.php"><i class="bi bi-house-door"></i> Home</a></li>
        <li class="nav-item"><a class="nav-link text-danger" href="../auth/logout.php"><i class="bi bi-box-arrow-right"></i> Logout</a></li>
      </ul>
    </div>
  </div>
</nav>
