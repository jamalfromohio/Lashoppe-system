<?php
// admin/inc_admin_auth.php

// Always include DB connection
require_once __DIR__ . '/../includes/db_connect.php';

// Start session if not already
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if user is logged in
if (empty($_SESSION['user_id'])) {
    // Not logged in
    header('Location: ../auth/login.php');
    exit;
}

// Check if user is an admin
if (empty($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    // Not admin → redirect to homepage
    header('Location: ../index.php');
    exit;
}

// You can also define a helper function if needed:
function isAdmin() {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
}
?>
