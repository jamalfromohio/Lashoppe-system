<?php
// add_product.php
session_start(); // ✅ must be at the top before any output

$page_title = "Admin Dashboard";

// Step 1: Include core dependencies
require_once __DIR__ . '/../includes/db_connect.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/inc_admin_auth.php'; // Step 2: Enforce admin-only access

// ✅ Step 3: Generate CSRF token if not set
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$errors = [];
$success = '';

// fetch categories
$categories = [];
$catRes = $mysqli->query("SELECT category_id, name FROM categories ORDER BY name");
if ($catRes) {
    while ($c = $catRes->fetch_assoc()) $categories[] = $c;
    $catRes->close();
}

// handle submit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // ✅ CSRF check (safe)
    if (
        empty($_POST['csrf_token']) ||
        !isset($_SESSION['csrf_token']) ||
        !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])
    ) {
        $errors[] = 'Invalid CSRF token. Please reload the page.';
    }

    $name = trim($_POST['name'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $price = isset($_POST['price']) ? (float)$_POST['price'] : 0;
    $stock = isset($_POST['stock']) ? (int)$_POST['stock'] : 0;
    $category_id = isset($_POST['category_id']) && $_POST['category_id'] !== '' ? (int)$_POST['category_id'] : null;

    if ($name === '') $errors[] = 'Name is required.';
    if ($price <= 0) $errors[] = 'Price must be greater than 0.';
    if ($stock < 0) $errors[] = 'Stock cannot be negative.';

    // validate category if provided
    if ($category_id !== null) {
        $chk = $mysqli->prepare("SELECT category_id FROM categories WHERE category_id = ? LIMIT 1");
        $chk->bind_param('i', $category_id);
        $chk->execute();
        $chk->store_result();
        if ($chk->num_rows === 0) $errors[] = 'Selected category does not exist.';
        $chk->close();
    }

    // image upload handling
    $image_filename = null;
    if (!empty($_FILES['image']) && $_FILES['image']['error'] !== UPLOAD_ERR_NO_FILE) {
        $allowed = ['image/jpeg','image/png','image/gif','image/webp'];
        $maxBytes = 2 * 1024 * 1024; // 2MB
        if ($_FILES['image']['error'] !== UPLOAD_ERR_OK) {
            $errors[] = 'Image upload error.';
        } else {
            if ($_FILES['image']['size'] > $maxBytes) $errors[] = 'Image too large (max 2MB).';
            $finfo = finfo_open(FILEINFO_MIME_TYPE);
            $mime = finfo_file($finfo, $_FILES['image']['tmp_name']);
            finfo_close($finfo);
            if (!in_array($mime, $allowed)) $errors[] = 'Invalid image type.';
            if (empty($errors)) {
                $ext = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
                $image_filename = uniqid('p_', true) . '.' . $ext;
                $dest = __DIR__ . '/../uploads/' . $image_filename;
                if (!move_uploaded_file($_FILES['image']['tmp_name'], $dest)) $errors[] = 'Failed to move uploaded image.';
            }
        }
    }

    // insert if no errors
    if (empty($errors)) {
        if ($category_id === null) {
            $stmt = $mysqli->prepare("INSERT INTO products (name, description, price, stock, image) VALUES (?, ?, ?, ?, ?)");
            $stmt->bind_param("ssdiss", $name, $description, $price, $stock, $image_filename);
        } else {
            $stmt = $mysqli->prepare("INSERT INTO products (name, description, price, stock, category_id, image) VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("ssdiis", $name, $description, $price, $stock, $category_id, $image_filename);
        }

        if ($stmt->execute()) {
            $_SESSION['flash'] = ['type'=>'success','msg'=>'Product added successfully.'];
            header('Location: manage_products.php');
            exit;
        } else {
            $errors[] = 'Insert failed: ' . $stmt->error;
        }
        $stmt->close();
    }
}

include __DIR__ . '/../includes/header.php';
?>

<div class="container py-4">
  <h3>Add Product</h3>

  <?php if (!empty($errors)): ?>
    <div class="alert alert-danger">
      <ul><?php foreach($errors as $e) echo '<li>'.htmlspecialchars($e).'</li>'; ?></ul>
    </div>
  <?php endif; ?>

  <form method="post" enctype="multipart/form-data">
    <!-- ✅ CSRF token added -->
    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>">

    <div class="mb-3">
      <label class="form-label">Name</label>
      <input class="form-control" name="name" value="<?= htmlspecialchars($_POST['name'] ?? '') ?>" required>
    </div>

    <div class="mb-3">
      <label class="form-label">Description</label>
      <textarea class="form-control" name="description"><?= htmlspecialchars($_POST['description'] ?? '') ?></textarea>
    </div>

    <div class="row">
      <div class="col-md-4 mb-3">
        <label class="form-label">Price</label>
        <input class="form-control" name="price" value="<?= htmlspecialchars($_POST['price'] ?? '') ?>" required>
      </div>
      <div class="col-md-4 mb-3">
        <label class="form-label">Stock</label>
        <input class="form-control" name="stock" value="<?= htmlspecialchars($_POST['stock'] ?? '0') ?>" required>
      </div>
      <div class="col-md-4 mb-3">
        <label class="form-label">Category</label>
        <select name="category_id" class="form-select">
          <option value="">-- No category --</option>
          <?php foreach($categories as $c): ?>
            <option value="<?= (int)$c['category_id'] ?>" <?= (isset($_POST['category_id']) && (int)$_POST['category_id'] === (int)$c['category_id']) ? 'selected' : '' ?>>
              <?= htmlspecialchars($c['name']) ?>
            </option>
          <?php endforeach; ?>
        </select>
      </div>
    </div>

    <div class="mb-3">
      <label class="form-label">Image (optional)</label>
      <input type="file" name="image" accept="image/*" class="form-control">
    </div>

    <button class="btn btn-primary">Add product</button>
    <a class="btn btn-secondary" href="manage_products.php">Cancel</a>
  </form>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
