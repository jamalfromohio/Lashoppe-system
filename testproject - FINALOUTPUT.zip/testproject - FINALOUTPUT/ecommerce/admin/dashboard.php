<?php
$page_title = "Admin Dashboard";

// Step 1: Include core dependencies
require_once __DIR__ . '/../includes/db_connect.php';
require_once __DIR__ . '/../includes/functions.php';

// Step 2: Enforce admin-only access
require_once __DIR__ . '/inc_admin_auth.php';

// Step 3: Load global header (auto-loads admin_nav.php if in /admin/)
include __DIR__ . '/../includes/header.php';

// Fetch statistics
$totalProducts = 0;
$totalOrders = 0;
$totalUsers = 0;

// Total products
$res = $mysqli->query("SELECT COUNT(*) AS cnt FROM products");
if ($res) {
    $totalProducts = (int)$res->fetch_assoc()['cnt'];
    $res->close();
}

// Total orders
$res = $mysqli->query("SELECT COUNT(*) AS cnt FROM orders");
if ($res) {
    $totalOrders = (int)$res->fetch_assoc()['cnt'];
    $res->close();
}

// Total users
$res = $mysqli->query("SELECT COUNT(*) AS cnt FROM users");
if ($res) {
    $totalUsers = (int)$res->fetch_assoc()['cnt'];
    $res->close();
}
?>

<!-- Admin Dashboard Header -->
<header class="bg-dark py-5">
  <div class="container px-4 px-lg-5 my-5">
    <div class="text-center text-white">
      <h1 class="display-4 fw-bolder">Admin Dashboard</h1>
      <p class="lead fw-normal text-white-50 mb-0">Manage your shop efficiently</p>
    </div>
  </div>
</header>

<!-- Dashboard content -->
<section class="py-5">
  <div class="container px-4 px-lg-5 mt-5">

    <!-- Welcome -->
    <div class="row mb-4">
      <div class="col-12 text-center">
        <h2>Welcome, <?= htmlspecialchars($_SESSION['username']) ?>!</h2>
        <p class="text-secondary">You are logged in as an admin.</p>
      </div>
    </div>

    <!-- Stats Section -->
    <div class="row gx-4 gx-lg-5 row-cols-1 row-cols-md-3 mb-5">
      <div class="col mb-4">
        <div class="card text-center h-100 shadow-sm">
          <div class="card-body">
            <h5 class="card-title">Total Products</h5>
            <p class="card-text display-6 fw-bold"><?= $totalProducts ?></p>
          </div>
        </div>
      </div>

      <div class="col mb-4">
        <div class="card text-center h-100 shadow-sm">
          <div class="card-body">
            <h5 class="card-title">Total Orders</h5>
            <p class="card-text display-6 fw-bold"><?= $totalOrders ?></p>
          </div>
        </div>
      </div>

      <div class="col mb-4">
        <div class="card text-center h-100 shadow-sm">
          <div class="card-body">
            <h5 class="card-title">Total Users</h5>
            <p class="card-text display-6 fw-bold"><?= $totalUsers ?></p>
          </div>
        </div>
      </div>
    </div>

    <!-- Action Cards Section -->
    <div class="row gx-4 gx-lg-5 row-cols-1 row-cols-md-2 row-cols-xl-3 justify-content-center">

      <!-- Manage Products Card -->
      <div class="col mb-5">
        <div class="card h-100 shadow-sm">
          <div class="card-body text-center">
            <h5 class="card-title">Manage Products</h5>
            <p class="card-text">Add, edit, or delete products from your store.</p>
            <a href="manage_products.php" class="btn btn-primary">Go</a>
          </div>
        </div>
      </div>

      <!-- View Orders Card -->
      <div class="col mb-5">
        <div class="card h-100 shadow-sm">
          <div class="card-body text-center">
            <h5 class="card-title">View Orders</h5>
            <p class="card-text">Check and manage customer orders.</p>
            <a href="orders.php" class="btn btn-primary">Go</a>
          </div>
        </div>
      </div>

      <!-- Login Logs Card -->
      <div class="col mb-5">
        <div class="card h-100 shadow-sm">
          <div class="card-body text-center">
            <h5 class="card-title">Login Logs</h5>
            <p class="card-text">View login activity for all users.</p>
            <a href="login_logs.php" class="btn btn-primary">Go</a>
          </div>
        </div>
      </div>

    </div>
  </div>
</section>

<?php include '../includes/footer.php'; ?>
