<?php
// admin/login.php
require_once '../includes/db_connect.php';
if (session_status() === PHP_SESSION_NONE) session_start();

$errors = [];
$ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';

// Handle POST login
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username_or_email = trim($_POST['username_or_email'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($username_or_email === '' || $password === '') {
        $errors[] = 'Please enter both username/email and password.';
    } else {
        // Check if user exists (by username or email)
        $stmt = $mysqli->prepare("SELECT user_id, username, email, password_hash, role FROM users WHERE username = ? OR email = ? LIMIT 1");
        $stmt->bind_param('ss', $username_or_email, $username_or_email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($row = $result->fetch_assoc()) {
            if ($row['role'] !== 'admin') {
                $errors[] = 'Access denied. Only admins can log in here.';

                // Log failed login (non-admin tried admin access)
                $log = $mysqli->prepare("INSERT INTO login_logs (user_id, username, ip, success) VALUES (?, ?, ?, 0)");
                $log->bind_param('iss', $row['user_id'], $row['username'], $ip);
                $log->execute();
                $log->close();

            } elseif (password_verify($password, $row['password_hash'])) {
                // ✅ Successful login
                $_SESSION['user_id'] = $row['user_id'];
                $_SESSION['username'] = $row['username'];
                $_SESSION['role'] = $row['role'];

                // Log successful login
                $log = $mysqli->prepare("INSERT INTO login_logs (user_id, username, ip, success) VALUES (?, ?, ?, 1)");
                $log->bind_param('iss', $row['user_id'], $row['username'], $ip);
                $log->execute();
                $log->close();

                header('Location: dashboard.php');
                exit;
            } else {
                $errors[] = 'Invalid password.';

                // Log failed login (wrong password)
                $log = $mysqli->prepare("INSERT INTO login_logs (user_id, username, ip, success) VALUES (?, ?, ?, 0)");
                $log->bind_param('iss', $row['user_id'], $row['username'], $ip);
                $log->execute();
                $log->close();
            }
        } else {
            $errors[] = 'No admin account found with that username/email.';

            // Log failed login (unknown username)
            $log = $mysqli->prepare("INSERT INTO login_logs (user_id, username, ip, success) VALUES (NULL, ?, ?, 0)");
            $log->bind_param('ss', $username_or_email, $ip);
            $log->execute();
            $log->close();
        }

        $stmt->close();
    }
}

$page_title = "Admin Login";
include '../includes/header.php';
?>

<section class="bg-light py-5">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-12 col-sm-10 col-md-8 col-lg-6 col-xl-5 col-xxl-4">
        <div class="card border border-light-subtle rounded-3 shadow-sm">
          <div class="card-body p-3 p-md-4 p-xl-5">
            <div class="text-center mb-3">
              <a href="../index.php">
                <img src="../uploads/forsignup.png" alt="Logo" width="175" height="57">
              </a>
            </div>
            <h2 class="fs-6 fw-normal text-center text-secondary mb-4">Admin Sign In</h2>

            <?php if (!empty($errors)): ?>
              <div class="alert alert-danger"><ul class="mb-0">
                <?php foreach ($errors as $e): ?><li><?= htmlspecialchars($e) ?></li><?php endforeach; ?>
              </ul></div>
            <?php endif; ?>

            <form action="login.php" method="POST" novalidate>
              <div class="form-floating mb-3">
                <input type="text" class="form-control" name="username_or_email" id="username_or_email" placeholder="Username or Email" required>
                <label for="username_or_email">Username or Email</label>
              </div>

              <div class="form-floating mb-3">
                <input type="password" class="form-control" name="password" id="password" placeholder="Password" required>
                <label for="password">Password</label>
              </div>

              <div class="d-grid my-3">
                <button class="btn btn-primary btn-lg" type="submit">Sign in</button>
              </div>

              <p class="m-0 text-secondary text-center">
                Go back to <a href="../index.php" class="link-primary text-decoration-none">Homepage</a>
              </p>
            </form>

          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<?php include '../includes/footer.php'; ?>
