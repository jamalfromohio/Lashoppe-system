<?php
$page_title = "Login Logs";

require_once __DIR__ . '/../includes/db_connect.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/inc_admin_auth.php'; // restrict to admins only
include __DIR__ . '/../includes/header.php';

// --- Search filter ---
$search = trim($_GET['search'] ?? '');
$sql = "
    SELECT id, user_id, username, ip, success, created_at
    FROM login_logs
";
$params = [];
if ($search !== '') {
    $sql .= " WHERE username LIKE CONCAT('%', ?, '%') OR ip LIKE CONCAT('%', ?, '%')";
    $params = [$search, $search];
}
$sql .= " ORDER BY created_at DESC LIMIT 300"; // limit for performance

$stmt = $mysqli->prepare($sql);
if (!empty($params)) {
    $stmt->bind_param('ss', ...$params);
}
$stmt->execute();
$result = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title><?= htmlspecialchars($page_title) ?></title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
  <style>
    body { background-color: #f8f9fa; }
    .table td, .table th { vertical-align: middle; }
    .table-success { background-color: #d4edda !important; }
    .table-danger { background-color: #f8d7da !important; }
  </style>
</head>
<body class="bg-light">
<div class="container py-4">
  <div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="mb-0">🧾 Login Activity Logs</h2>
    <a href="dashboard.php" class="btn btn-secondary btn-sm">← Back to Dashboard</a>
  </div>

  <!-- 🔍 Search form -->
  <form method="GET" class="input-group mb-4" style="max-width: 500px;">
    <input 
      type="text" 
      name="search" 
      class="form-control" 
      placeholder="Search by username or IP..." 
      value="<?= htmlspecialchars($search) ?>"
    >
    <button class="btn btn-primary" type="submit">Search</button>
    <?php if ($search !== ''): ?>
      <a href="login_logs.php" class="btn btn-outline-secondary">Clear</a>
    <?php endif; ?>
  </form>

  <?php if ($result && $result->num_rows > 0): ?>
  <div class="table-responsive shadow-sm rounded-3">
    <table class="table table-bordered table-hover bg-white align-middle">
      <thead class="table-dark text-center">
        <tr>
          <th>#</th>
          <th>Username</th>
          <th>User ID</th>
          <th>IP Address</th>
          <th>Status</th>
          <th>Date & Time</th>
        </tr>
      </thead>
      <tbody>
        <?php while ($row = $result->fetch_assoc()): ?>
          <tr class="<?= $row['success'] ? 'table-success' : 'table-danger' ?>">
            <td class="text-center"><?= htmlspecialchars($row['id']) ?></td>
            <td><?= htmlspecialchars($row['username'] ?: 'Unknown') ?></td>
            <td class="text-center"><?= htmlspecialchars($row['user_id'] ?: '-') ?></td>
            <td><?= htmlspecialchars($row['ip']) ?></td>
            <td class="text-center fw-bold">
              <?= $row['success'] ? '✅ Success' : '❌ Failed' ?>
            </td>
            <td><?= htmlspecialchars($row['created_at']) ?></td>
          </tr>
        <?php endwhile; ?>
      </tbody>
    </table>
  </div>
  <?php else: ?>
    <p class="text-center text-muted mt-4">No login logs found.</p>
  <?php endif; ?>
</div>
</body>
</html>
<?php include '../includes/footer.php'; ?>
