

<?php
// admin/manage_products.php
$page_title = "Admin Dashboard";

// Step 1: Include core dependencies
require_once __DIR__ . '/../includes/db_connect.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/config.php';

// Step 2: Enforce admin-only access
require_once __DIR__ . '/inc_admin_auth.php';



// Simple flash messages using session
if (session_status() === PHP_SESSION_NONE) session_start();
$flash = $_SESSION['flash'] ?? null;
unset($_SESSION['flash']);

// CSRF token for delete forms
if (empty($_SESSION['csrf_token'])) $_SESSION['csrf_token'] = bin2hex(random_bytes(24));
$csrf = $_SESSION['csrf_token'];

// Handle POST delete (safe)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'delete') {
    // Validate CSRF
    if (empty($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
        $_SESSION['flash'] = ['type'=>'danger','msg'=>'Invalid CSRF token.'];
        header('Location: manage_products.php');
        exit;
    }

    $id = isset($_POST['product_id']) ? (int)$_POST['product_id'] : 0;
    if ($id > 0) {
        // optional: get image filename to delete from uploads
        $stmt = $mysqli->prepare("SELECT image FROM products WHERE product_id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $res = $stmt->get_result();
        $row = $res->fetch_assoc();
        $stmt->close();

        // delete DB row
        $del = $mysqli->prepare("DELETE FROM products WHERE product_id = ?");
        $del->bind_param("i", $id);
        if ($del->execute()) {
            // unlink image file if exists
            if (!empty($row['image'])) {
                $file = __DIR__ . '/../uploads/' . $row['image'];
                if (file_exists($file)) @unlink($file);
            }
            $_SESSION['flash'] = ['type'=>'success','msg'=>'Product deleted.'];
        } else {
            $_SESSION['flash'] = ['type'=>'danger','msg'=>'Delete failed: ' . $del->error];
        }
        $del->close();
    } else {
        $_SESSION['flash'] = ['type'=>'warning','msg'=>'Invalid product id.'];
    }

    header('Location: ' . BASE_URL . '/admin/manage_products.php');
    exit;
}

// fetch products (basic list, add pagination if needed)
include __DIR__ . '/../includes/header.php';

$perPage = 20;
$page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
$offset = ($page - 1) * $perPage;

// total count for pagination
$countRes = $mysqli->query("SELECT COUNT(*) AS cnt FROM products");
$total = ($countRes) ? (int)$countRes->fetch_assoc()['cnt'] : 0;
$totalPages = max(1, ceil($total / $perPage));

// main query with category name
$stmt = $mysqli->prepare("
  SELECT p.product_id, p.name, p.price, p.stock, p.image, c.name AS category_name
  FROM products p
  LEFT JOIN categories c ON p.category_id = c.category_id
  ORDER BY p.product_id DESC
  LIMIT ? OFFSET ?
");
$stmt->bind_param("ii", $perPage, $offset);
$stmt->execute();
$res = $stmt->get_result();
?>
<div class="container py-4">
  <div class="d-flex justify-content-between align-items-center mb-3">
    <h3>Manage Products</h3>
    <a class="btn btn-success" href="add_product.php">Add Product</a>
  </div>

  <?php if ($flash): ?>
    <div class="alert alert-<?= htmlspecialchars($flash['type']) ?>"><?= htmlspecialchars($flash['msg']) ?></div>
  <?php endif; ?>

  <table class="table table-striped">
    <thead><tr><th>ID</th><th>Image</th><th>Name</th><th>Price</th><th>Stock</th><th>Category</th><th>Actions</th></tr></thead>
    <tbody>
      <?php while ($row = $res->fetch_assoc()): ?>
        <tr>
          <td><?= (int)$row['product_id'] ?></td>
          <td>
            <?php if (!empty($row['image']) && file_exists(__DIR__ . '/../uploads/' . $row['image'])): ?>
             <img src="<?= BASE_URL ?>/uploads/<?= htmlspecialchars($row['image']) ?>" 
               alt="<?= htmlspecialchars($row['name']) ?>" 
                  style="height:60px;object-fit:cover">
            <?php else: ?>
              <img src="https://dummyimage.com/80x60/dee2e6/6c757d.jpg" alt="" style="height:60px">
            <?php endif; ?>
          </td>
          <td><?= htmlspecialchars($row['name']) ?></td>
          <td>₱<?= number_format($row['price'],2) ?></td>
          <td><?= (int)$row['stock'] ?></td>
          <td><?= htmlspecialchars($row['category_name'] ?? '') ?></td>
          <td>
            <a class="btn btn-sm btn-primary" href="edit_product.php?id=<?= (int)$row['product_id'] ?>">Edit</a>

            <!-- Delete form (POST + CSRF) -->
            <form method="post" action="manage_products.php" style="display:inline" onsubmit="return confirm('Delete this product?');">
              <input type="hidden" name="action" value="delete">
              <input type="hidden" name="product_id" value="<?= (int)$row['product_id'] ?>">
              <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf) ?>">
              <button class="btn btn-sm btn-danger" type="submit">Delete</button>
            </form>
          </td>
        </tr>
      <?php endwhile; ?>
      <?php if ($total === 0): ?>
        <tr><td colspan="7">No products found.</td></tr>
      <?php endif; ?>
    </tbody>
  </table>

  <!-- Pagination (simple) -->
  <?php if ($totalPages > 1): ?>
    <nav>
      <ul class="pagination">
        <?php for ($p = 1; $p <= $totalPages; $p++): ?>
          <li class="page-item <?= $p === $page ? 'active' : '' ?>"><a class="page-link" href="manage_products.php?page=<?= $p ?>"><?= $p ?></a></li>
        <?php endfor; ?>
      </ul>
    </nav>
  <?php endif; ?>
</div>

<?php
$stmt->close();
include __DIR__ . '/../includes/footer.php';
