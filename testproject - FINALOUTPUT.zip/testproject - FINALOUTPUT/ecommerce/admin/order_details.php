<?php
// admin/order_details.php
session_start();
require_once __DIR__ . '/../includes/db_connect.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/inc_admin_auth.php'; // admin-only
include __DIR__ . '/../includes/header.php';

// Validate & get order_id
$order_id = isset($_GET['order_id']) ? (int)$_GET['order_id'] : 0;
if ($order_id <= 0) {
    die('<div class="alert alert-danger text-center mt-5">Invalid order ID.</div>');
}

// Fetch order info and user details
$sql = "
    SELECT 
        o.order_id,
        o.order_date,
        o.status,
        o.total_amount,
        o.shipping_address,
        u.username,
        u.email,
        u.date_joined
    FROM orders o
    JOIN users u ON o.user_id = u.user_id
    WHERE o.order_id = ?
";
$stmt = $mysqli->prepare($sql);
$stmt->bind_param("i", $order_id);
$stmt->execute();
$order = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$order) {
    die('<div class="alert alert-warning text-center mt-5">Order not found.</div>');
}

// Fetch ordered items
$sql_items = "
    SELECT 
        oi.quantity,
        oi.price,
        p.name AS product_name,
        p.image
    FROM order_items oi
    JOIN products p ON oi.product_id = p.product_id
    WHERE oi.order_id = ?
";
$stmt = $mysqli->prepare($sql_items);
$stmt->bind_param("i", $order_id);
$stmt->execute();
$items = $stmt->get_result();
$stmt->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Order Details #<?= htmlspecialchars($order_id) ?></title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
</head>
<body class="bg-light">

<div class="container py-5">
  <div class="d-flex justify-content-between align-items-center mb-4">
    <h2>📦 Order #<?= htmlspecialchars($order['order_id']) ?></h2>
    <a href="orders.php" class="btn btn-secondary">← Back to Orders</a>
  </div>

  <!-- Order Summary -->
  <div class="card mb-4 shadow-sm">
    <div class="card-header bg-primary text-white">
      <h5 class="mb-0">Order Information</h5>
    </div>
    <div class="card-body">
      <p><strong>Order Date:</strong> <?= htmlspecialchars($order['order_date']) ?></p>
      <p><strong>Status:</strong> <span class="badge bg-info text-dark"><?= htmlspecialchars($order['status']) ?></span></p>
      <p><strong>Total Amount:</strong> ₱<?= number_format($order['total_amount'], 2) ?></p>
      <p><strong>Shipping Address:</strong> <?= htmlspecialchars($order['shipping_address']) ?></p>
    </div>
  </div>

  <!-- Customer Info -->
  <div class="card mb-4 shadow-sm">
    <div class="card-header bg-success text-white">
      <h5 class="mb-0">Customer Information</h5>
    </div>
    <div class="card-body">
      <p><strong>Username:</strong> <?= htmlspecialchars($order['username']) ?></p>
      <p><strong>Email:</strong> <?= htmlspecialchars($order['email']) ?></p>
      <p><strong>Member Since:</strong> <?= date('F j, Y', strtotime($order['date_joined'])) ?></p>
    </div>
  </div>

  <!-- Ordered Items -->
  <div class="card shadow-sm">
    <div class="card-header bg-dark text-white">
      <h5 class="mb-0">Items in This Order</h5>
    </div>
    <div class="card-body p-0">
      <div class="table-responsive">
        <table class="table table-bordered table-striped mb-0">
          <thead class="table-light text-center">
            <tr>
              <th>Product</th>
              <th>Image</th>
              <th>Quantity</th>
              <th>Price</th>
              <th>Subtotal</th>
            </tr>
          </thead>
          <tbody>
            <?php 
            $grandTotal = 0;
            while ($item = $items->fetch_assoc()): 
              $subtotal = $item['quantity'] * $item['price'];
              $grandTotal += $subtotal;
            ?>
            <tr>
              <td><?= htmlspecialchars($item['product_name']) ?></td>
              <td class="text-center">
                <?php if (!empty($item['image'])): ?>
                  <img src="../uploads/<?= htmlspecialchars($item['image']) ?>" width="60" alt="">
                <?php else: ?>
                  <span class="text-muted">No image</span>
                <?php endif; ?>
              </td>
              <td class="text-center"><?= (int)$item['quantity'] ?></td>
              <td class="text-end">₱<?= number_format($item['price'], 2) ?></td>
              <td class="text-end">₱<?= number_format($subtotal, 2) ?></td>
            </tr>
            <?php endwhile; ?>
          </tbody>
        </table>
      </div>
    </div>
    <div class="card-footer text-end fw-bold">
      Grand Total: ₱<?= number_format($grandTotal, 2) ?>
    </div>
  </div>
</div>

</body>
</html>

<?php include '../includes/footer.php'; ?>
