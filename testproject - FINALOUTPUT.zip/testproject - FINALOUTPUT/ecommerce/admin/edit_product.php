<?php
$page_title = "Admin Dashboard";

// Step 1: Include core dependencies
require_once __DIR__ . '/../includes/db_connect.php';
require_once __DIR__ . '/../includes/functions.php';

// Step 2: Enforce admin-only access
require_once __DIR__ . '/inc_admin_auth.php';


$errors = [];

if (!isset($_GET['id'])) {
    header('Location: manage_products.php');
    exit;
}
$id = (int)$_GET['id'];

// fetch product
$stmt = $mysqli->prepare("SELECT * FROM products WHERE product_id = ? LIMIT 1");
$stmt->bind_param('i', $id);
$stmt->execute();
$res = $stmt->get_result();
$product = $res->fetch_assoc();
$stmt->close();

if (!$product) {
    $_SESSION['flash'] = ['type'=>'warning','msg'=>'Product not found'];
    header('Location: manage_products.php');
    exit;
}

// fetch categories
$categories = [];
$catRes = $mysqli->query("SELECT category_id, name FROM categories ORDER BY name");
if ($catRes) {
    while ($c = $catRes->fetch_assoc()) $categories[] = $c;
    $catRes->close();
}

// handle POST update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (empty($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
        $errors[] = 'Invalid CSRF token.';
    }

    $name = trim($_POST['name'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $price = isset($_POST['price']) ? (float)$_POST['price'] : 0;
    $stock = isset($_POST['stock']) ? (int)$_POST['stock'] : 0;
    $category_id = isset($_POST['category_id']) && $_POST['category_id'] !== '' ? (int)$_POST['category_id'] : null;

    if ($name === '') $errors[] = 'Name required.';
    if ($price <= 0) $errors[] = 'Price must be greater than 0.';
    if ($stock < 0) $errors[] = 'Stock invalid.';

    if ($category_id !== null) {
        $chk = $mysqli->prepare("SELECT category_id FROM categories WHERE category_id = ? LIMIT 1");
        $chk->bind_param('i', $category_id);
        $chk->execute();
        $chk->store_result();
        if ($chk->num_rows === 0) $errors[] = 'Selected category does not exist.';
        $chk->close();
    }

    // image upload (optional replace)
    $new_image = null;
    if (!empty($_FILES['image']) && $_FILES['image']['error'] !== UPLOAD_ERR_NO_FILE) {
        $allowed = ['image/jpeg','image/png','image/gif','image/webp'];
        $maxBytes = 2 * 1024 * 1024;
        if ($_FILES['image']['error'] !== UPLOAD_ERR_OK) {
            $errors[] = 'Image upload error.';
        } else {
            if ($_FILES['image']['size'] > $maxBytes) $errors[] = 'Image too large (max 2MB).';
            $finfo = finfo_open(FILEINFO_MIME_TYPE);
            $mime = finfo_file($finfo, $_FILES['image']['tmp_name']);
            finfo_close($finfo);
            if (!in_array($mime, $allowed)) $errors[] = 'Invalid image type.';
            if (empty($errors)) {
                $ext = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
                $new_image = uniqid('p_', true) . '.' . $ext;
                $dest = __DIR__ . '/../uploads/' . $new_image;
                if (!move_uploaded_file($_FILES['image']['tmp_name'], $dest)) $errors[] = 'Failed to move uploaded image.';
            }
        }
    }

    if (empty($errors)) {
        // build update SQL dynamically
        if ($category_id === null) {
            if ($new_image === null) {
                $stmt = $mysqli->prepare("UPDATE products SET name=?, description=?, price=?, stock=?, category_id=NULL WHERE product_id=?");
                $stmt->bind_param('ssdii', $name, $description, $price, $stock, $id);
            } else {
                $stmt = $mysqli->prepare("UPDATE products SET name=?, description=?, price=?, stock=?, category_id=NULL, image=? WHERE product_id=?");
                $stmt->bind_param('ssdisi', $name, $description, $price, $stock, $new_image, $id);
            }
        } else {
            if ($new_image === null) {
                $stmt = $mysqli->prepare("UPDATE products SET name=?, description=?, price=?, stock=?, category_id=? WHERE product_id=?");
                $stmt->bind_param('ssdiii', $name, $description, $price, $stock, $category_id, $id);
            } else {
                $stmt = $mysqli->prepare("UPDATE products SET name=?, description=?, price=?, stock=?, category_id=?, image=? WHERE product_id=?");
                $stmt->bind_param('ssdiisi', $name, $description, $price, $stock, $category_id, $new_image, $id);
            }
        }

        if ($stmt->execute()) {
            // if replaced image, unlink old
            if ($new_image !== null && !empty($product['image'])) {
                $old = __DIR__ . '/../uploads/' . $product['image'];
                if (file_exists($old)) @unlink($old);
            }
            $_SESSION['flash'] = ['type'=>'success','msg'=>'Product updated.'];
            header('Location: manage_products.php');
            exit;
        } else {
            $errors[] = 'Update failed: ' . $stmt->error;
        }
        $stmt->close();
    }
}

include __DIR__ . '/../includes/header.php';
?>
<div class="container py-4">
  <h3>Edit Product</h3>

  <?php if (!empty($errors)): ?>
    <div class="alert alert-danger"><ul><?php foreach($errors as $e) echo '<li>'.htmlspecialchars($e).'</li>'; ?></ul></div>
  <?php endif; ?>

  <form method="post" enctype="multipart/form-data">
    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>">

    <div class="mb-3">
      <label class="form-label">Name</label>
      <input class="form-control" name="name" value="<?= htmlspecialchars($_POST['name'] ?? $product['name']) ?>" required>
    </div>

    <div class="mb-3">
      <label class="form-label">Description</label>
      <textarea class="form-control" name="description"><?= htmlspecialchars($_POST['description'] ?? $product['description']) ?></textarea>
    </div>

    <div class="row">
      <div class="col-md-4 mb-3">
        <label class="form-label">Price</label>
        <input class="form-control" name="price" value="<?= htmlspecialchars($_POST['price'] ?? $product['price']) ?>" required>
      </div>
      <div class="col-md-4 mb-3">
        <label class="form-label">Stock</label>
        <input class="form-control" name="stock" value="<?= htmlspecialchars($_POST['stock'] ?? $product['stock']) ?>" required>
      </div>
      <div class="col-md-4 mb-3">
        <label class="form-label">Category</label>
        <select name="category_id" class="form-select">
          <option value="">-- No category --</option>
          <?php foreach($categories as $c): 
            $sel = (isset($_POST['category_id']) ? (int)$_POST['category_id'] : (int)$product['category_id']) === (int)$c['category_id'];
          ?>
            <option value="<?= (int)$c['category_id'] ?>" <?= $sel ? 'selected' : '' ?>>
              <?= htmlspecialchars($c['name']) ?>
            </option>
          <?php endforeach; ?>
        </select>
      </div>
    </div>

    <div class="mb-3">
      <label class="form-label">Replace Image (leave empty to keep current)</label>
      <input type="file" name="image" accept="image/*" class="form-control">
      <?php if (!empty($product['image']) && file_exists(__DIR__ . '/../uploads/' . $product['image'])): ?>
        <div class="mt-2"><img src="../uploads/<?= htmlspecialchars($product['image']) ?>" style="height:100px;object-fit:cover"></div>
      <?php endif; ?>
    </div>

    <button class="btn btn-primary">Save changes</button>
    <a class="btn btn-secondary" href="manage_products.php">Cancel</a>
  </form>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
