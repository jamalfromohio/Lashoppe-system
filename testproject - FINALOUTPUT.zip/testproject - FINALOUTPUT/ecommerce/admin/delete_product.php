<?php
$page_title = "Admin Dashboard";

// Step 1: Include core dependencies
require_once __DIR__ . '/../includes/db_connect.php';
require_once __DIR__ . '/../includes/functions.php';

// Step 2: Enforce admin-only access
require_once __DIR__ . '/inc_admin_auth.php';

// Step 3: Load global header (auto-loads admin_nav.php if in /admin/)
include __DIR__ . '/../includes/header.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: manage_products.php');
    exit;
}

if (empty($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
    $_SESSION['flash'] = ['type'=>'danger','msg'=>'Invalid CSRF token.'];
    header('Location: manage_products.php');
    exit;
}

$id = isset($_POST['product_id']) ? (int)$_POST['product_id'] : 0;
if ($id <= 0) {
    $_SESSION['flash'] = ['type'=>'warning','msg'=>'Invalid product id.'];
    header('Location: manage_products.php');
    exit;
}

// fetch image
$stmt = $mysqli->prepare("SELECT image FROM products WHERE product_id = ? LIMIT 1");
$stmt->bind_param('i', $id);
$stmt->execute();
$res = $stmt->get_result();
$row = $res->fetch_assoc();
$stmt->close();

// delete
$del = $mysqli->prepare("DELETE FROM products WHERE product_id = ?");
$del->bind_param('i', $id);
if ($del->execute()) {
    if (!empty($row['image'])) {
        $file = __DIR__ . '/../uploads/' . $row['image'];
        if (file_exists($file)) @unlink($file);
    }
    $_SESSION['flash'] = ['type'=>'success','msg'=>'Product deleted.'];
} else {
    $_SESSION['flash'] = ['type'=>'danger','msg'=>'Delete failed: '.$del->error];
}
$del->close();
header('Location: manage_products.php');
exit;
