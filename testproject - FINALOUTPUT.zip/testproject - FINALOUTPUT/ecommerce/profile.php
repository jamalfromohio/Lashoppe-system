<?php
// profile.php
session_start();
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/db_connect.php';

// 🔒 Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: ' . BASE_URL . '/auth/login.php');
    exit;
}

$user_id = $_SESSION['user_id'];

// 🧾 Fetch user info
$stmt = $mysqli->prepare("SELECT username, email, date_joined FROM users WHERE user_id = ?");
$stmt->bind_param('i', $user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
$stmt->close();

// 🛍️ Fetch user's orders
$orders_query = "
    SELECT order_id, order_date, status, total_amount, shipping_address
    FROM orders
    WHERE user_id = ?
    ORDER BY order_date DESC
";
$stmt = $mysqli->prepare($orders_query);
$stmt->bind_param('i', $user_id);
$stmt->execute();
$orders = $stmt->get_result();
$stmt->close();
?>

<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>My Profile</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="container py-5">
  <div class="row justify-content-center">
    <div class="col-lg-8">
      
      <!-- Profile Info -->
      <div class="card mb-4 shadow-sm">
        <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
          <h4 class="mb-0">Profile Information</h4>
          <a href="<?= BASE_URL ?>/auth/logout.php" class="btn btn-sm btn-light">Logout</a>
        </div>
        <div class="card-body">
          <p><strong>Username:</strong> <?= htmlspecialchars($user['username']) ?></p>
          <p><strong>Email:</strong> <?= htmlspecialchars($user['email']) ?></p>
          <p><strong>Member Since:</strong> <?= htmlspecialchars(date('F j, Y', strtotime($user['date_joined']))) ?></p>
        </div>
      </div>

      <!-- Order History -->
      <div class="card shadow-sm">
        <div class="card-header bg-secondary text-white">
          <h4 class="mb-0">My Orders</h4>
        </div>
        <div class="card-body">
          <?php if ($orders->num_rows > 0): ?>
            <div class="table-responsive">
              <table class="table table-striped align-middle">
                <thead>
                  <tr>
                    <th>Order #</th>
                    <th>Date</th>
                    <th>Status</th>
                    <th>Total</th>
                    <th>Shipping Address</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                <?php while ($order = $orders->fetch_assoc()): ?>
                  <tr>
                    <td>#<?= htmlspecialchars($order['order_id']) ?></td>
                    <td><?= date('M j, Y', strtotime($order['order_date'])) ?></td>
                    <td><span class="badge bg-info text-dark"><?= htmlspecialchars($order['status']) ?></span></td>
                    <td>₱<?= number_format($order['total_amount'], 2) ?></td>
                    <td><?= htmlspecialchars($order['shipping_address']) ?></td>
                    <td>
                      <a href="<?= BASE_URL ?>/order_details.php?order_id=<?= $order['order_id'] ?>" class="btn btn-sm btn-outline-primary">
                        View
                      </a>
                    </td>
                  </tr>
                <?php endwhile; ?>
                </tbody>
              </table>
            </div>
          <?php else: ?>
            <p class="text-muted">You have not placed any orders yet.</p>
          <?php endif; ?>
        </div>
      </div>

      <a href="<?= BASE_URL ?>/index.php" class="btn btn-link mt-3">← Back to Shop</a>

    </div>
  </div>
</div>

</body>
</html>
