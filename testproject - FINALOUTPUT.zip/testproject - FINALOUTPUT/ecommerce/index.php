<?php
$page_title = "Shop Homepage";
require 'includes/db_connect.php';
require 'includes/functions.php';
include 'includes/header.php';

// Fetch products (change limit as needed)
$products = getProducts(12); // returns array of associative arrays

$categories = [];
$catRes = $mysqli->query("SELECT category_id, name FROM categories ORDER BY name");
if ($catRes) {
    while ($c = $catRes->fetch_assoc()) $categories[] = $c;
    $catRes->close();
}
?>
<!-- Header (kept from template) -->
<header class="bg-dark py-5">
  <div class="container px-4 px-lg-5 my-5">
    <div class="text-center text-white">
      <h1 class="display-4 fw-bolder">Welcome to Lashoppee!</h1>
      <p class="lead fw-normal text-white-50 mb-0">where all product is broken</p>
    </div>
  </div>
</header>

<!-- Section: product grid -->
<section class="py-5">
  <div class="container px-4 px-lg-5 mt-5">
    <div class="row gx-4 gx-lg-5 row-cols-2 row-cols-md-3 row-cols-xl-4 justify-content-center">

      <?php if (!empty($products)): ?>
        <?php foreach ($products as $p): 
          // fallback image if missing
          $img = !empty($p['image']) ? 'uploads/' . $p['image'] : 'https://dummyimage.com/450x300/dee2e6/6c757d.jpg';
          $name = htmlspecialchars($p['name']);
          $price = number_format((float)$p['price'], 2);
        ?>
        <div class="col mb-5">
          <div class="card h-100">
            <!-- Optional: sale badge -->
            <?php if (!empty($p['is_on_sale'])): ?>
              <div class="badge bg-dark text-white position-absolute" style="top: 0.5rem; right: 0.5rem">Sale</div>
            <?php endif; ?>

            <!-- Product image-->
            <img class="card-img-top" src="<?= $img ?>" alt="<?= $name ?>" />

            <!-- Product details-->
            <div class="card-body p-4">
              <div class="text-center">
                <h5 class="fw-bolder"><?= $name ?></h5>
                <p>₱<?= $price ?></p>
              </div>
            </div>

            <!-- Product actions-->
            <div class="card-footer p-4 pt-0 border-top-0 bg-transparent">
              <div class="text-center">
                <a class="btn btn-outline-dark mt-auto" href="product.php?id=<?= (int)$p['product_id'] ?>">
                  View Details
                </a>
                <a class="btn btn-outline-primary mt-auto" href="cart.php?action=add&id=<?= (int)$p['product_id'] ?>">
                  Add to cart
                </a>
              </div>
            </div>

          </div>
        </div>
        <?php endforeach; ?>
      <?php else: ?>
        <p>No products found.</p>
      <?php endif; ?>

    </div>
  </div>
</section>

<?php include 'includes/footer.php'; ?>
