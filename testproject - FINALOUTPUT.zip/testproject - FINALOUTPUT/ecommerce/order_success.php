<?php
require 'includes/db_connect.php';
include 'includes/header.php';
$id = isset($_GET['order_id']) ? (int)$_GET['order_id'] : 0;
?>
<div class="container py-4">
  <h3>Order Placed</h3>
  <?php if ($id): ?>
    <p>Your order #<?= $id ?> was placed successfully. Thank you!</p>
  <?php else: ?>
    <p>No order ID supplied.</p>
  <?php endif; ?>
  <a href="index.php" class="btn btn-primary">Continue shopping</a>
</div>
<?php include 'includes/footer.php'; ?>
