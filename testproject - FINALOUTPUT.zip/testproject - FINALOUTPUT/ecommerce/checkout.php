<?php
// checkout.php
require 'includes/db_connect.php';
require 'includes/functions.php';
if (session_status() === PHP_SESSION_NONE) session_start();
include 'includes/header.php';

$user_id = $_SESSION['user_id'] ?? null;

if (empty($_SESSION['cart'])) {
    echo '<div class="container py-4"><p>Your cart is empty. <a href="index.php">Shop now</a></p></div>';
    include 'includes/footer.php';
    exit;
}

// fetch product data
$ids = array_keys($_SESSION['cart']);
$placeholders = implode(',', array_fill(0, count($ids), '?'));
$types = str_repeat('i', count($ids));
$stmt = $mysqli->prepare("SELECT product_id, name, price, stock FROM products WHERE product_id IN ($placeholders)");
$stmt->bind_param($types, ...$ids);
$stmt->execute();
$res = $stmt->get_result();
$products = [];
while ($r = $res->fetch_assoc()) $products[$r['product_id']] = $r;
$stmt->close();

$total = 0.0;
foreach ($_SESSION['cart'] as $pid => $qty) {
    if (!isset($products[$pid])) continue;
    $total += $products[$pid]['price'] * $qty;
}

$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $shipping_address = trim($_POST['shipping_address'] ?? '');

    if (!$user_id) {
        if ($name === '') $errors[] = 'Name required';
        if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Valid email required';
    }
    if ($shipping_address === '') $errors[] = 'Shipping address required';

    if (empty($errors)) {
        $mysqli->begin_transaction();
        try {
            $order_user = $user_id;
            $stmt = $mysqli->prepare("INSERT INTO orders (user_id, order_date, status, total_amount, shipping_address) VALUES (?, NOW(), 'paid', ?, ?)");
            $stmt->bind_param("ids", $order_user, $total, $shipping_address);
            $stmt->execute();
            $order_id = $stmt->insert_id;
            $stmt->close();

            $stmtItem = $mysqli->prepare("INSERT INTO order_items (order_id, product_id, quantity, price) VALUES (?, ?, ?, ?)");
            foreach ($_SESSION['cart'] as $pid => $qty) {
                if (!isset($products[$pid])) continue;
                $price = (float)$products[$pid]['price'];
                $stmtItem->bind_param("iiid", $order_id, $pid, $qty, $price);
                $stmtItem->execute();
                $mysqli->query("UPDATE products SET stock = stock - " . ((int)$qty) . " WHERE product_id = " . (int)$pid);
            }
            $stmtItem->close();

            $payMethod = 'guest_pay';
            $stmtPay = $mysqli->prepare("INSERT INTO payments (order_id, amount, payment_method, payment_date, status) VALUES (?, ?, ?, NOW(), 'success')");
            $stmtPay->bind_param("ids", $order_id, $total, $payMethod);
            $stmtPay->execute();
            $stmtPay->close();

            $mysqli->commit();

            unset($_SESSION['cart']);
            header("Location: order_success.php?order_id=" . (int)$order_id);
            exit;
        } catch (Exception $e) {
            $mysqli->rollback();
            $errors[] = "Checkout failed: " . $e->getMessage();
        }
    }
}
?>
<div class="container py-4">
  <h3>Checkout</h3>
  <?php if (!empty($errors)): ?>
    <div style="color:red"><ul><?php foreach ($errors as $e) echo "<li>" . htmlspecialchars($e) . "</li>"; ?></ul></div>
  <?php endif; ?>

  <div class="row">
    <div class="col-md-6">
      <form method="post">
        <?php if (!$user_id): ?>
          <label>Name:<br><input type="text" name="name" required></label><br><br>
          <label>Email:<br><input type="email" name="email" required></label><br><br>
        <?php else: ?>
          <p>Checkout as user id <?= (int)$user_id ?></p>
        <?php endif; ?>

        <label>Shipping address:<br>
          <textarea name="shipping_address" required rows="4"><?= htmlspecialchars($_POST['shipping_address'] ?? '') ?></textarea>
        </label><br><br>

        <button class="btn btn-success" type="submit">Place Order (simulate payment)</button>
      </form>
    </div>

    <div class="col-md-6">
      <h5>Order Summary</h5>
      <ul>
        <?php foreach ($_SESSION['cart'] as $pid => $qty):
            if (!isset($products[$pid])) continue;
            $p = $products[$pid];
        ?>
          <li><?= htmlspecialchars($p['name']) ?> x <?= (int)$qty ?> — ₱<?= number_format($p['price'] * $qty,2) ?></li>
        <?php endforeach; ?>
      </ul>
      <h4>Total: ₱<?= number_format($total,2) ?></h4>
    </div>
  </div>
</div>

<?php include 'includes/footer.php'; ?>
