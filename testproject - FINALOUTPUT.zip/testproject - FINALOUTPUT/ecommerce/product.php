<?php
// product.php
require 'includes/db_connect.php';
require 'includes/functions.php';
if (session_status() === PHP_SESSION_NONE) session_start();
include 'includes/header.php';

// get id
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($id <= 0) {
    echo '<div class="container py-4"><p>Invalid product id.</p></div>';
    include 'includes/footer.php';
    exit;
}

// fetch product
$stmt = $mysqli->prepare("SELECT p.*, c.name AS category_name FROM products p LEFT JOIN categories c ON p.category_id = c.category_id WHERE p.product_id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$product = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$product) {
    echo '<div class="container py-4"><p>Product not found.</p></div>';
    include 'includes/footer.php';
    exit;
}

$img = !empty($product['image']) ? 'uploads/' . $product['image'] : 'https://dummyimage.com/800x500/dee2e6/6c757d.jpg';
?>
<div class="container py-4">
  <div class="row">
    <div class="col-md-6">
      <img src="<?= htmlspecialchars($img) ?>" alt="<?= htmlspecialchars($product['name']) ?>" class="img-fluid">
    </div>
    <div class="col-md-6">
      <h2><?= htmlspecialchars($product['name']) ?></h2>
      <p class="text-muted"><?= htmlspecialchars($product['category_name'] ?? 'Uncategorized') ?></p>
      <p><?= nl2br(htmlspecialchars($product['description'])) ?></p>
      <h4>₱<?= number_format($product['price'],2) ?></h4>
      <p>Stock: <?= (int)$product['stock'] ?></p>

      <form action="cart.php?action=add&id=<?= (int)$product['product_id'] ?>" method="post" class="mb-3">
        <label>Quantity:
          <input type="number" name="qty" value="1" min="1" max="<?= max(1,(int)$product['stock']) ?>">
        </label><br><br>
        <button class="btn btn-primary" type="submit">Add to Cart</button>
      </form>

      <a href="index.php" class="btn btn-link">Back to shop</a>
    </div>
  </div>
</div>

<?php include 'includes/footer.php'; ?>
