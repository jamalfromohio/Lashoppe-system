<?php
// includes/header.php
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/config.php';

// Detect if current page is under /admin/
$is_admin_page = strpos($_SERVER['PHP_SELF'], '/admin/') !== false;
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
  <title><?= isset($page_title) ? htmlspecialchars($page_title) : 'Shop Homepage' ?></title>

  <link rel="icon" type="image/x-icon" href="<?= BASE_PATH ?>/assets/favicon.ico" />
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css" rel="stylesheet" />
  <link href="<?= BASE_PATH ?>/assets/homepage/css/styles.css" rel="stylesheet" />
  <link rel="stylesheet" href="https://unpkg.com/bootstrap@5.3.3/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="<?= BASE_PATH ?>/css/styles.css">
</head>

<body class="bg-dark text-light">

<?php
// ✅ Only load ONE navbar
if ($is_admin_page) {
    include __DIR__ . '/../admin/admin_nav.php';
} else {
?>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <div class="container px-4 px-lg-5">
    <a class="navbar-brand" href="<?= BASE_PATH ?>/index.php">Your Store</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
      data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
      aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>

    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <!-- Left links -->
      <ul class="navbar-nav me-auto mb-2 mb-lg-0 ms-lg-4">
        <li class="nav-item"><a class="nav-link active" href="<?= BASE_PATH ?>/index.php">Home</a></li>
        <li class="nav-item"><a class="nav-link" href="#">About</a></li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" id="navbarDropdown" href="#" data-bs-toggle="dropdown">Shop</a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
            <li><a class="dropdown-item" href="<?= BASE_PATH ?>/products.php">All Products</a></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item" href="#">Popular Items</a></li>
            <li><a class="dropdown-item" href="#">New Arrivals</a></li>
          </ul>
        </li>
      </ul>

      <!-- Account links -->
      <ul class="navbar-nav mb-2 mb-lg-0 me-3">
        <?php if (!empty($_SESSION['username'])): ?>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" id="accountDropdown" href="#" data-bs-toggle="dropdown">
              <?= htmlspecialchars($_SESSION['username']) ?>
            </a>
            <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="accountDropdown">
              <li><a class="dropdown-item" href="<?= BASE_PATH ?>/profile.php">Profile</a></li>
              <?php if (($_SESSION['role'] ?? '') === 'admin'): ?>
                <li><a class="dropdown-item" href="<?= BASE_PATH ?>/admin/dashboard.php">Admin Dashboard</a></li>
              <?php endif; ?>
              <li><hr class="dropdown-divider"></li>
              <li><a class="dropdown-item" href="<?= BASE_PATH ?>/auth/logout.php">Logout</a></li>
            </ul>
          </li>
        <?php else: ?>
          <li class="nav-item"><a class="nav-link" href="<?= BASE_PATH ?>/auth/login.php">Login</a></li>
          <li class="nav-item"><a class="nav-link" href="<?= BASE_PATH ?>/auth/register.php">Register</a></li>
        <?php endif; ?>
      </ul>

      <!-- Cart -->
      <form class="d-flex" action="<?= BASE_PATH ?>/cart.php" method="get">
        <?php
          $cart_count = 0;
          if (!empty($_SESSION['cart']) && is_array($_SESSION['cart'])) {
            foreach ($_SESSION['cart'] as $qty) $cart_count += (int)$qty;
          }
        ?>
        <button class="btn btn-outline-dark" type="submit">
          <i class="bi-cart-fill me-1"></i>
          Cart
          <span class="badge bg-dark text-white ms-1 rounded-pill"><?= $cart_count ?></span>
        </button>
      </form>
    </div>
  </div>
</nav>
<?php } ?>
