<?php
$host = 'localhost';
$db   = 'ecommerce_db';
$user = 'root';
$pass = ''; // default for XAMPP
$charset = 'utf8mb4';

$mysqli = new mysqli($host, $user, $pass, $db);
if ($mysqli->connect_errno) {
    die("DB connection failed: " . $mysqli->connect_error);
}
$mysqli->set_charset($charset);
?>
