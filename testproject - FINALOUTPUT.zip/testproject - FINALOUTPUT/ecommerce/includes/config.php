<?php
// includes/config.php
// ✅ Centralized configuration for your whole project

// The full base URL of your site (used in links and redirects)
if (!defined('BASE_URL')) {
    define('BASE_URL', 'http://localhost/testproject/ecommerce');
}

// The base path (used for file includes)
if (!defined('BASE_PATH')) {
    define('BASE_PATH', '/testproject/ecommerce');
}
