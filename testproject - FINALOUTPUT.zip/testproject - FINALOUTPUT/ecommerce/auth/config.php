<?php
// config.php
$DB_HOST = 'localhost';
$DB_NAME = 'your_database';
$DB_USER = 'your_db_user';
$DB_PASS = 'your_db_password';

$options = [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
];

try {
    $pdo = new PDO("mysql:host=$DB_HOST;dbname=$DB_NAME;charset=utf8mb4", $DB_USER, $DB_PASS, $options);
} catch (PDOException $e) {
    // In production, don't echo exception details
    exit('Database connection failed.');
}
