<?php
// auth/login.php

// 🧩 Debugging mode (disable in production)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// ✅ Start session safely
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// ✅ Include required files
require '../includes/db_connect.php';
require_once '../includes/config.php';

// Initialize errors array
$errors = [];
$ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';

// ✅ Handle login form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username_or_email = trim($_POST['username_or_email'] ?? '');
    $password = trim($_POST['password'] ?? '');

    if ($username_or_email === '' || $password === '') {
        $errors[] = 'Please enter both username/email and password.';
    } else {
        // Check if user exists
        $stmt = $mysqli->prepare("
            SELECT user_id, username, email, password_hash, role 
            FROM users 
            WHERE username = ? OR email = ? 
            LIMIT 1
        ");
        $stmt->bind_param('ss', $username_or_email, $username_or_email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($user = $result->fetch_assoc()) {
            if (password_verify($password, $user['password_hash'])) {
                // ✅ Successful login → set session
                $_SESSION['user_id'] = $user['user_id'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['role'] = $user['role'];

                // ✅ Log successful login
                $log = $mysqli->prepare("
                    INSERT INTO login_logs (user_id, username, ip, success) 
                    VALUES (?, ?, ?, 1)
                ");
                $log->bind_param('iss', $user['user_id'], $user['username'], $ip);
                $log->execute();
                $log->close();

                // ✅ Redirect based on role
                if ($user['role'] === 'admin') {
                    header('Location: ' . BASE_URL . '/admin/dashboard.php');
                } else {
                    header('Location: ' . BASE_URL . '/index.php');
                }
                exit;
            } else {
                // ❌ Invalid password
                $errors[] = 'Invalid password.';

                // Log failed attempt (existing user)
                $log = $mysqli->prepare("
                    INSERT INTO login_logs (user_id, username, ip, success) 
                    VALUES (?, ?, ?, 0)
                ");
                $log->bind_param('iss', $user['user_id'], $user['username'], $ip);
                $log->execute();
                $log->close();
            }
        } else {
            // ❌ Non-existent user
            $errors[] = 'No account found with that username/email.';

            // Log failed attempt (non-existent user)
            $log = $mysqli->prepare("
                INSERT INTO login_logs (user_id, username, ip, success) 
                VALUES (NULL, ?, ?, 0)
            ");
            $log->bind_param('ss', $username_or_email, $ip);
            $log->execute();
            $log->close();
        }

        $stmt->close();
    }
}
?>

<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Login</title>
  <link rel="stylesheet" href="https://unpkg.com/bootstrap@5.3.3/dist/css/bootstrap.min.css">
  <style>
    .btn-color { background-color:#0e1c36; color:#fff; }
    .cardbody-color { background-color:#ebf2fa; }
    a { text-decoration:none; }
  </style>
</head>
<body>
<section class="bg-light py-3 py-md-5">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-12 col-sm-10 col-md-8 col-lg-6 col-xl-5 col-xxl-4">
        <div class="card border border-light-subtle rounded-3 shadow-sm">
          <div class="card-body p-3 p-md-4 p-xl-5">
            <div class="text-center mb-3">
              <a href="../index.php">
                <img src="../uploads/forsignup.png" alt="Logo" width="175" height="57">
              </a>
            </div>
            <h2 class="fs-6 fw-normal text-center text-secondary mb-4">Sign in to your account</h2>

            <?php if (!empty($errors)): ?>
              <div class="alert alert-danger">
                <ul class="mb-0">
                  <?php foreach ($errors as $e): ?>
                    <li><?= htmlspecialchars($e) ?></li>
                  <?php endforeach; ?>
                </ul>
              </div>
            <?php endif; ?>

            <form action="login.php" method="POST" novalidate>
              <div class="form-floating mb-3">
                <input type="text" class="form-control" name="username_or_email" id="username_or_email" 
                       placeholder="Username or Email" required 
                       value="<?= htmlspecialchars($_POST['username_or_email'] ?? '') ?>">
                <label for="username_or_email">Username or Email</label>
              </div>

              <div class="form-floating mb-3">
                <input type="password" class="form-control" name="password" id="password" 
                       placeholder="Password" required>
                <label for="password">Password</label>
              </div>

              <div class="d-grid my-3">
                <button class="btn btn-primary btn-lg" type="submit">Sign in</button>
              </div>

              <p class="m-0 text-secondary text-center">
                Don’t have an account? <a href="register.php" class="link-primary text-decoration-none">Sign up</a>
              </p>
            </form>

          </div>
        </div>
      </div>
    </div>
  </div>
</section>
</body>
</html>
