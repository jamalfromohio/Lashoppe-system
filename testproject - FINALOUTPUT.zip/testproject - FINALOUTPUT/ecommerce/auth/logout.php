<?php
session_start();
session_unset();
session_destroy();
header('Location: /testproject/ecommerce/index.php');
exit;
?>
