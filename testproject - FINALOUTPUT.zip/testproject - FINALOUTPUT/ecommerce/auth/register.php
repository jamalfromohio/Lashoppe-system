<?php
// auth/register.php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/db_connect.php';
if (session_status() === PHP_SESSION_NONE) session_start();

// CSRF protection
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(24));
}
$csrf_token = $_SESSION['csrf_token'];

$errors = [];
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // verify CSRF
    if (empty($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
        $errors[] = 'Invalid CSRF token. Please refresh the page and try again.';
    }

    $username = trim($_POST['username'] ?? '');
    $email    = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $iAgree   = isset($_POST['iAgree']);

    // validation
    if ($username === '' || strlen($username) < 3) $errors[] = 'Username must be at least 3 characters.';
    if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Valid email is required.';
    if (strlen($password) < 6) $errors[] = 'Password must be at least 6 characters.';
    if (!$iAgree) $errors[] = 'You must agree to the terms and conditions.';

    if (empty($errors)) {
        // check if username or email already exist
        $stmt = $mysqli->prepare("SELECT user_id FROM users WHERE username = ? OR email = ? LIMIT 1");
        $stmt->bind_param("ss", $username, $email);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $errors[] = 'Username or email already exists.';
            $stmt->close();
        } else {
            $stmt->close();
            $password_hash = password_hash($password, PASSWORD_DEFAULT);
            $role = 'customer';

            $ins = $mysqli->prepare("INSERT INTO users (username, email, password_hash, role, date_joined) VALUES (?, ?, ?, ?, NOW())");
            $ins->bind_param("ssss", $username, $email, $password_hash, $role);

            if ($ins->execute()) {
                $success = 'Account created successfully! You can now <a href="login.php">log in</a>.';
                $_POST = []; // clear form
            } else {
                $errors[] = 'Registration failed: ' . $ins->error;
            }
            $ins->close();
        }
    }

    // regenerate CSRF token after submission
    $_SESSION['csrf_token'] = bin2hex(random_bytes(24));
    $csrf_token = $_SESSION['csrf_token'];
}
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Register</title>
  <link rel="stylesheet" href="../css/styles.css">
  <link rel="stylesheet" href="https://unpkg.com/bootstrap@5.3.3/dist/css/bootstrap.min.css">
  <style>
    .btn-color{background-color:#0e1c36;color:#fff;}
    .cardbody-color{background-color:#ebf2fa;}
    a{text-decoration:none;}
  </style>
</head>
<body>
<section class="bg-light py-3 py-md-5">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-12 col-sm-10 col-md-8 col-lg-6 col-xl-5 col-xxl-4">
        <div class="card border border-light-subtle rounded-3 shadow-sm">
          <div class="card-body p-3 p-md-4 p-xl-5">
            <div class="text-center mb-3">
             <a href="<?= BASE_PATH ?>/index.php">
                 <img src="<?= BASE_PATH ?>/uploads/forsignup.png" alt="Logo" width="175" height="57">
        </a>
            </div>
            <h2 class="fs-6 fw-normal text-center text-secondary mb-4">Create your account</h2>

            <?php if ($success): ?>
              <div class="alert alert-success"><?= $success ?></div>
            <?php endif; ?>

            <?php if (!empty($errors)): ?>
              <div class="alert alert-danger"><ul class="mb-0">
                <?php foreach ($errors as $e): ?>
                  <li><?= htmlspecialchars($e) ?></li>
                <?php endforeach; ?>
              </ul></div>
            <?php endif; ?>

            <form action="register.php" method="POST" novalidate>
              <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf_token) ?>">

              <div class="form-floating mb-3">
                <input type="text" class="form-control" name="username" id="username" placeholder="Username" required value="<?= htmlspecialchars($_POST['username'] ?? '') ?>">
                <label for="username">Username</label>
              </div>

              <div class="form-floating mb-3">
                <input type="email" class="form-control" name="email" id="email" placeholder="name@example.com" required value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">
                <label for="email">Email</label>
              </div>

              <div class="form-floating mb-3">
                <input type="password" class="form-control" name="password" id="password" placeholder="Password" required>
                <label for="password">Password</label>
              </div>

              <div class="form-check mb-3">
                <input class="form-check-input" type="checkbox" value="1" name="iAgree" id="iAgree" <?= isset($_POST['iAgree']) ? 'checked' : '' ?> required>
                <label class="form-check-label text-secondary" for="iAgree">
                  I agree to the <a href="#!" class="link-primary text-decoration-none">terms and conditions</a>
                </label>
              </div>

              <div class="d-grid my-3">
                <button class="btn btn-primary btn-lg" type="submit">Sign up</button>
              </div>

              <p class="m-0 text-secondary text-center">Already have an account? <a href="login.php" class="link-primary text-decoration-none">Sign in</a></p>
            </form>

          </div>
        </div>
      </div>
    </div>
  </div>
</section>
</body>
</html>
