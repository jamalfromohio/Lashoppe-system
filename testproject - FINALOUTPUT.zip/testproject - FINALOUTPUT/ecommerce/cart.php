<?php
// cart.php
require 'includes/db_connect.php';
require 'includes/functions.php';
if (session_status() === PHP_SESSION_NONE) session_start();

if (!isset($_SESSION['cart']) || !is_array($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

$action = $_GET['action'] ?? 'view';
function redirect($u){ header("Location: $u"); exit; }

if ($action === 'add') {
    $id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
    $qty = isset($_POST['qty']) ? (int)$_POST['qty'] : 1;
    if ($id > 0 && $qty > 0) {
        if (isset($_SESSION['cart'][$id])) $_SESSION['cart'][$id] += $qty;
        else $_SESSION['cart'][$id] = $qty;
    }
    redirect('cart.php');
}

if ($action === 'update') {
    if (!empty($_POST['qty']) && is_array($_POST['qty'])) {
        foreach ($_POST['qty'] as $pid => $q) {
            $pid = (int)$pid; $q = (int)$q;
            if ($pid > 0) {
                if ($q > 0) $_SESSION['cart'][$pid] = $q;
                else unset($_SESSION['cart'][$pid]);
            }
        }
    }
    redirect('cart.php');
}

if ($action === 'remove') {
    $id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
    if ($id > 0 && isset($_SESSION['cart'][$id])) unset($_SESSION['cart'][$id]);
    redirect('cart.php');
}

// view
include 'includes/header.php';

if (empty($_SESSION['cart'])) {
    echo '<div class="container py-4"><h3>Your cart is empty.</h3><a href="index.php" class="btn btn-primary">Continue shopping</a></div>';
    include 'includes/footer.php';
    exit;
}

// fetch product rows
$ids = array_keys($_SESSION['cart']);
$placeholders = implode(',', array_fill(0, count($ids), '?'));
$types = str_repeat('i', count($ids));
$stmt = $mysqli->prepare("SELECT product_id, name, price, image FROM products WHERE product_id IN ($placeholders)");
$stmt->bind_param($types, ...$ids);
$stmt->execute();
$res = $stmt->get_result();
$products = [];
while ($r = $res->fetch_assoc()) $products[$r['product_id']] = $r;
$stmt->close();

$subtotal = 0.0;
?>
<div class="container py-4">
  <h3>Your Cart</h3>
  <form action="cart.php?action=update" method="post">
    <table class="table">
      <thead><tr><th>Product</th><th>Price</th><th>Qty</th><th>Line</th><th></th></tr></thead>
      <tbody>
      <?php foreach ($_SESSION['cart'] as $pid => $qty):
        if (!isset($products[$pid])) continue;
        $p = $products[$pid];
        $line = $qty * (float)$p['price'];
        $subtotal += $line;
      ?>
        <tr>
          <td>
            <img src="<?= !empty($p['image']) ? 'uploads/' . htmlspecialchars($p['image']) : 'https://dummyimage.com/80x60/dee2e6/6c757d.jpg' ?>" width="80" alt="">
            <?= htmlspecialchars($p['name']) ?>
          </td>
          <td>₱<?= number_format($p['price'],2) ?></td>
          <td><input type="number" name="qty[<?= (int)$pid ?>]" value="<?= (int)$qty ?>" min="0" style="width:80px"></td>
          <td>₱<?= number_format($line,2) ?></td>
          <td><a href="cart.php?action=remove&id=<?= (int)$pid ?>" class="btn btn-sm btn-danger">Remove</a></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
    <div class="mb-3">
      <button class="btn btn-primary" type="submit">Update Cart</button>
      <a href="checkout.php" class="btn btn-success">Proceed to Checkout</a>
      <a href="index.php" class="btn btn-link">Continue shopping</a>
    </div>
  </form>

  <div class="float-end">
    <h4>Subtotal: ₱<?= number_format($subtotal,2) ?></h4>
  </div>
</div>

<?php include 'includes/footer.php'; ?>
